# CostCraft Manager 📊💼

**CostCraft Manager** adalah aplikasi web berbasis *Client-Side* yang dirancang untuk membantu perhitungan dan analisis akuntansi biaya perusahaan manufaktur atau jasa. Aplikasi ini menghitung komponen biaya tetap (*Fixed Cost*), biaya variabel (*Variable Cost*), total biaya (*Total Cost*), margin kontribusi, serta Analisis Titik Impas (*Break-Even Point* / BEP dalam Unit & Rupiah) beserta simulasi target laba.

## 🚀 Fitur Utama
- **Kalkulator Biaya Tetap (Fixed Cost):** Menjumlahkan seluruh biaya operasional yang tidak berubah terlepas dari volume produksi (seperti sewa gedung, gaji tetap, penyusutan).
- **Kalkulator Biaya Variabel (Variable Cost):** Menghitung total biaya variabel berdasarkan jumlah unit produksi dan biaya per unit.
- **Analisis Break-Even Point (BEP):** 
  - BEP Unit (Berapa unit produk yang harus terjual agar balik modal).
  - BEP Rupiah (Total omzet penjualan minimal untuk mencapai titik impas).
- **Simulasi Target Laba:** Menghitung jumlah unit dan omzet yang dibutuhkan untuk mencapai target keuntungan tertentu.
- **Format Mata Uang Otomatis:** Menampilkan hasil perhitungan dalam format Rupiah (IDR) secara rapi.
- **Desain Responsif & Modern:** Antarmuka bersih menggunakan CSS murni dengan tata letak grid dan flexbox.

## 🛠️ Teknologi yang Digunakan
- **HTML5:** Struktur semantik web.
- **CSS3:** Styling kustom, variabel CSS, Flexbox & CSS Grid, serta efek transisi modern.
- **JavaScript (ES6+):** Logika perhitungan akuntansi keuangan dan manipulasi DOM interaktif.

## 📂 Struktur Repository
```text
costcraft-manager/
├── index.html       # Halaman utama antarmuka aplikasi
├── style.css        # Desain dan tata letak tampilan
├── script.js        # Logika perhitungan dan interaksi pengguna
├── .gitignore       # Konfigurasi file yang diabaikan Git
└── README.md        # Dokumentasi proyek
```

## ⚙️ Cara Menjalankan (Lokal)
1. Clone repository ini atau ekstrak file ZIP proyek ini:
   ```bash
   git clone https://github.com/username/costcraft-manager.git
   ```
2. Buka folder proyek di teks editor (seperti VS Code).
3. Buka file `index.html` menggunakan browser atau gunakan ekstensi **Live Server** di VS Code.

## 💡 Lisensi
Proyek ini bersifat *open-source* dan bebas digunakan untuk keperluan edukasi maupun komersial.
