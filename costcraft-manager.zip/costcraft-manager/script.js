document.getElementById('costForm').addEventListener('submit', function (e) {
    e.preventDefault();

    // 1. Ambil nilai dari input form
    const fixedCost = parseFloat(document.getElementById('fixedCost').value) || 0;
    const variableCostPerUnit = parseFloat(document.getElementById('variableCostPerUnit').value) || 0;
    const sellingPricePerUnit = parseFloat(document.getElementById('sellingPricePerUnit').value) || 0;
    const targetProduction = parseFloat(document.getElementById('targetProduction').value) || 0;
    const targetProfit = parseFloat(document.getElementById('targetProfit').value) || 0;

    // 2. Validasi sederhana
    if (sellingPricePerUnit <= variableCostPerUnit) {
        alert('Peringatan: Harga jual per unit harus lebih besar dari biaya variabel per unit agar perusahaan dapat menutupi biaya dan mendapat keuntungan!');
        return;
    }

    // 3. Perhitungan Akuntansi Biaya
    // Total Biaya Variabel (TVC) = Biaya Variabel per Unit × Target Produksi
    const totalVariableCost = variableCostPerUnit * targetProduction;

    // Total Biaya (TC) = Biaya Tetap (TFC) + Total Biaya Variabel (TVC)
    const totalCost = fixedCost + totalVariableCost;

    // Margin Kontribusi per Unit = Harga Jual - Biaya Variabel per Unit
    const contributionMarginUnit = sellingPricePerUnit - variableCostPerUnit;

    // Break-Even Point (BEP) Unit = Biaya Tetap / Margin Kontribusi per Unit
    const bepUnit = fixedCost / contributionMarginUnit;

    // Break-Even Point (BEP) Rupiah = BEP Unit × Harga Jual per Unit
    const bepRupiah = bepUnit * sellingPricePerUnit;

    // Total Pendapatan (Revenue) = Harga Jual × Target Produksi
    const totalRevenue = sellingPricePerUnit * targetProduction;

    // Laba / Rugi Bersih = Total Pendapatan - Total Biaya
    const netProfit = totalRevenue - totalCost;

    // Target Unit untuk Target Laba = (Biaya Tetap + Target Laba) / Margin Kontribusi per Unit
    const targetUnitForProfit = (fixedCost + targetProfit) / contributionMarginUnit;

    // 4. Format Mata Uang Rupiah (IDR)
    const formatIDR = (number) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            maximumFractionDigits: 0
        }).format(number);
    };

    // 5. Tampilkan hasil ke UI
    document.getElementById('resTotalCost').textContent = formatIDR(totalCost);
    document.getElementById('descTotalCost').textContent = `TFC (${formatIDR(fixedCost)}) + TVC (${formatIDR(totalVariableCost)})`;
    document.getElementById('resMarginUnit').textContent = formatIDR(contributionMarginUnit);
    document.getElementById('resBepUnit').textContent = `${Math.ceil(bepUnit).toLocaleString('id-ID')} Unit`;
    document.getElementById('resBepRupiah').textContent = formatIDR(bepRupiah);
    
    document.getElementById('resRevenue').textContent = formatIDR(totalRevenue);
    
    const profitElement = document.getElementById('resNetProfit');
    profitElement.textContent = formatIDR(netProfit);
    if (netProfit >= 0) {
        profitElement.className = 'profit';
    } else {
        profitElement.className = 'loss';
    }

    document.getElementById('resTargetUnit').textContent = `${Math.ceil(targetUnitForProfit).toLocaleString('id-ID')} Unit`;

    // Status Operasional
    const statusBadge = document.getElementById('resStatus');
    if (targetProduction >= bepUnit) {
        statusBadge.textContent = 'AMAN (Di atas BEP)';
        statusBadge.style.backgroundColor = '#d1fae5';
        statusBadge.style.color = '#065f46';
    } else {
        statusBadge.textContent = 'BERBAHAYA (Di bawah BEP / Rugi)';
        statusBadge.style.backgroundColor = '#fee2e2';
        statusBadge.style.color = '#991b1b';
    }
});
